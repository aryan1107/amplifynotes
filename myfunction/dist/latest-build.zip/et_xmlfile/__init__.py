from __future__ import absolute_import

from .xmlfile import xmlfile

# constants
__version__ = '1.1.0'

__author__ = 'See ATUHORS.txt'
__license__ = 'MIT'
__author_email__ = 'charlie.clark@clark-consulting.eu'
__url__ = 'https://foss.heptapod.net/openpyxl/et_xmlfile'
